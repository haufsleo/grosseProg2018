java -jar ../Netzplanerstellung.jar .in ../Testfaelle/Normalfaelle/
java -jar ../Netzplanerstellung.jar .in ../Testfaelle/Sonderfaelle/
java -jar ../Netzplanerstellung.jar .in ../Testfaelle/Fehlerfaelle/